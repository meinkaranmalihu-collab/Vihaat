from pathlib import Path
p=Path('/mnt/data/vihaat_fix_work/public/dashboard.html')
s=p.read_text()
# Remove mobile Shipping & Fulfilment section, keep the AI banner and all other sections.
s=s.replace('<div class="mobile-tool-section"><div class="mobile-section-heading"><h2>Shipping &amp; Fulfilment</h2><span>03</span></div><div class="mobile-tools" id="mobileToolsShipping"></div></div>', '')
# Actual markup uses unescaped ampersand in HTML source
s=s.replace('<div class="mobile-tool-section"><div class="mobile-section-heading"><h2>Shipping & Fulfilment</h2><span>03</span></div><div class="mobile-tools" id="mobileToolsShipping"></div></div>', '')
# Renumber sections after removing shipping tools
s=s.replace('<h2>Returns &amp; Profit</h2><span>04</span>', '<h2>Returns &amp; Profit</h2><span>03</span>')
s=s.replace('<h2>Returns & Profit</h2><span>04</span>', '<h2>Returns & Profit</h2><span>03</span>')
s=s.replace('<h2>AI &amp; Growth</h2><span>05</span>', '<h2>AI &amp; Growth</h2><span>04</span>')
s=s.replace('<h2>AI & Growth</h2><span>05</span>', '<h2>AI & Growth</h2><span>04</span>')
s=s.replace('<h2>Product Utilities</h2><span>06</span>', '<h2>Product Utilities</h2><span>05</span>')
s=s.replace('<h2>Automation Centre</h2><span>07</span>', '<h2>Automation Centre</h2><span>06</span>')
s=s.replace('<h2>Store & Insights</h2><span>08</span>', '<h2>Store & Insights</h2><span>07</span>')
# Remove carrier/shipping services from tool catalog, add Returns Analytics under returns/profit.
s=s.replace(" ['Shipping Rate Compare','shipping-rates.svg','Shipping & Fulfilment','Compare available shipping rates'],['Shipment Tracking','shipment-tracking.svg','Shipping & Fulfilment','Track shipments in one place'],['Pickup Scheduling','pickup-scheduling.svg','Shipping & Fulfilment','Plan carrier pickups'],['Delivery Alerts','delivery-alerts.svg','Shipping & Fulfilment','Flag delayed or failed deliveries'],\n ['Returns Analytics','returns-analytics.svg','Returns & Profit','Understand return and RTO patterns'],", " ['Returns Analytics','returns-analytics.svg','Returns & Profit','Understand return and RTO patterns'],")
# Remove shipping nav links and group; keep Returns Analytics in seller utilities.
s=s.replace("const navGroups=[['CORE',[['Home','home'],['Unified Orders','orders'],['Master Product','cube'],['Listings','list'],['Inventory','box'],['Marketplaces','shop'],['Shipping','truck'],['Returns','return']]],['SHIPPING & OPERATIONS',[['Shipping Rate Compare','truck'],['Shipment Tracking','search'],['Pickup Scheduling','list'],['Delivery Alerts','ai'],['Returns Analytics','chart']]],['AI & GROWTH'", "const navGroups=[['CORE',[['Home','home'],['Unified Orders','orders'],['Master Product','cube'],['Listings','list'],['Inventory','box'],['Marketplaces','shop'],['Returns','return']]],['AI & GROWTH'")
s=s.replace("['SELLER UTILITIES',[['Profit Dashboard','price'],['Marketplace Fee Calculator','price'],['GST & Margin Calculator','chart'],['SKU & Barcode Generator','list'],['Image Resizer','image']]]", "['SELLER UTILITIES',[['Returns Analytics','chart'],['Profit Dashboard','price'],['Marketplace Fee Calculator','price'],['GST & Margin Calculator','chart'],['SKU & Barcode Generator','list'],['Image Resizer','image']]]")
# Replace nav destinations object by removing service-specific destinations.
s=s.replace("'Shipping':'#mobileToolsShipping',", "")
s=s.replace("'Shipping Rate Compare':'#mobileToolsShipping','Shipment Tracking':'#mobileToolsShipping','Pickup Scheduling':'#mobileToolsShipping','Delivery Alerts':'#mobileToolsShipping',", "")
# Group target no longer includes shipping
s=s.replace("'Shipping & Fulfilment':'mobileToolsShipping',", "")
# Remove shipping descriptions if present
for line in [
" 'Shipping Rate Compare':'Compare shipping options once carrier or marketplace shipping integrations are configured.',\n",
" 'Shipment Tracking':'A unified tracking workspace for supported carrier and marketplace tracking feeds.',\n",
" 'Pickup Scheduling':'Organize pickup requests; automatic booking requires a supported shipping integration.',\n",
" 'Delivery Alerts':'Surface delayed shipments and delivery exceptions when tracking data is connected.',\n",
]: s=s.replace(line,'')
# Remove shipping tool click mappings
s=s.replace("'Shipping Rate Compare':'#mobileToolsShipping','Shipment Tracking':'#mobileToolsShipping','Pickup Scheduling':'#mobileToolsShipping','Delivery Alerts':'#mobileToolsShipping',", "")
# Upgrade marketplace card structure for a more premium compact presentation.
old='document.getElementById(\'marketplaceGrid\').innerHTML=list.map(m=>`<div class="market-card"><span class="market-logo"><img src="/assets/marketplaces/${m[1]}" alt="${m[0]}"></span><div class="market-info"><b>${m[0]}</b><small>${m[2]}</small></div><button class="connect-btn" data-market="${m[0]}">Connect</button></div>`).join(\'\');'
new='document.getElementById(\'marketplaceGrid\').innerHTML=list.map(m=>`<div class="market-card"><div class="market-card-top"><span class="market-logo"><img src="/assets/marketplaces/${m[1]}" alt="${m[0]}" loading="lazy"></span><span class="market-status"><i></i> Ready to connect</span></div><div class="market-info"><b>${m[0]}</b><small>${m[2]} · Sales channel</small></div><button class="connect-btn" data-market="${m[0]}">Connect channel <span aria-hidden="true">↗</span></button></div>`).join(\'\');'
if old not in s:
    print('WARNING marketplace template not found')
else: s=s.replace(old,new)
# More refined marketplace section heading copy.
s=s.replace('<h2>Connect Marketplaces</h2><div style="font-size:9px;color:var(--muted);margin-top:3px">Connect your sales channels and sync orders, listings and inventory.</div>', '<span class="market-kicker">SALES CHANNELS</span><h2>Connect your marketplaces</h2><div class="market-subtitle">Bring orders, listings and inventory into one workspace.</div>')
s=s.replace('<a>Manage All →</a>', '<a class="market-manage" href="#marketplaces">Manage channels <span aria-hidden="true">↗</span></a>')
# Append CSS overrides so the footer follows the user's pastel tile reference and marketplace panel feels polished.
css=r'''
/* Final polish: pastel footer navigation and premium marketplace connection cards */
.marketplace-connect{padding:18px;border:1px solid #e7e9f3;border-radius:22px;background:linear-gradient(145deg,#fff 0%,#fbfaff 100%);box-shadow:0 14px 36px rgba(26,27,59,.065)}
.marketplace-connect .head{align-items:flex-start;gap:14px;margin-bottom:16px}
.marketplace-connect .head h2{font-size:17px;letter-spacing:-.45px;font-weight:900;margin:3px 0 0}
.market-kicker{display:block;color:#7650f7;font-size:8px;font-weight:900;letter-spacing:1.8px}
.market-subtitle{max-width:460px;color:#7b8295;font-size:10px;line-height:1.5;margin-top:5px}
.market-manage{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;padding:9px 11px;border:1px solid #e4ddff;border-radius:11px;background:#f7f4ff;color:#6847ef!important;font-size:9px!important;font-weight:850}
.marketplace-grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.market-card{display:flex;flex-direction:column;align-items:stretch;gap:9px;padding:13px;border:1px solid #e9ebf4;border-radius:16px;background:linear-gradient(150deg,#fff,#fcfcff);box-shadow:0 5px 18px rgba(25,31,58,.035);transition:transform .18s,border-color .18s,box-shadow .18s}
.market-card:hover{transform:translateY(-2px);border-color:#d9d0ff;box-shadow:0 12px 26px rgba(73,55,146,.09)}
.market-card-top{display:flex;align-items:center;justify-content:space-between;gap:6px}
.market-logo{width:44px;height:44px;flex:0 0 44px;border-radius:13px;border-color:#edf0f7;background:#fff;box-shadow:0 3px 9px rgba(20,25,50,.035)}
.market-logo img{width:30px;height:30px}
.market-status{display:inline-flex;align-items:center;gap:4px;color:#81889a;font-size:7px;font-weight:750;white-space:nowrap}
.market-status i{width:5px;height:5px;border-radius:50%;background:#9ba3b5;display:inline-block}
.market-info{width:100%;min-height:30px}
.market-info b{font-size:11px;font-weight:850;color:#171c2b}
.market-info small{font-size:8px;color:#858b9b;margin-top:4px}
.connect-btn{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;margin:0;padding:9px 10px;border:1px solid #e1d9ff;border-radius:10px;background:linear-gradient(135deg,#f7f4ff,#eee8ff);color:#6546f6;font-size:9px;font-weight:850;box-shadow:inset 0 1px 0 rgba(255,255,255,.9);transition:background .18s,color .18s}
.connect-btn:hover{background:linear-gradient(135deg,#7049ff,#5b36e8);color:#fff;border-color:#7049ff}
.connect-btn span{font-size:12px;line-height:1}
/* Footer inspired by the approved reference: colorful pastel icon tiles, central circular AI, hamburger More. */
.mobile-nav{height:91px!important;grid-template-columns:repeat(5,minmax(0,1fr));align-items:center;padding:8px max(10px,env(safe-area-inset-left)) max(10px,env(safe-area-inset-bottom))!important;background:rgba(255,255,255,.96)!important;border-top:1px solid #e8eaf2!important;box-shadow:0 -12px 34px rgba(28,30,63,.09)!important;backdrop-filter:blur(20px)!important}
.mnav{align-content:center;justify-items:center;gap:5px;min-width:0;margin:0 2px;padding:3px 0;border-radius:15px;color:#858b9b;font-size:9px}
.mnav-icon{width:52px!important;height:48px!important;display:grid;place-items:center;border-radius:16px!important;background:#f1edff;box-shadow:inset 0 1px 0 rgba(255,255,255,.95);transition:transform .18s,box-shadow .18s}
.mnav-icon svg{width:25px!important;height:25px!important;stroke-width:1.9!important}
.mnav[data-tab="home"] .mnav-icon{background:linear-gradient(145deg,#f0eaff,#e7ddff);color:#7048f8}
.mnav[data-tab="orders"] .mnav-icon{background:linear-gradient(145deg,#e9f5ff,#d9edff);color:#1687e8}
.mnav[data-tab="inventory"] .mnav-icon{background:linear-gradient(145deg,#e4fbf6,#d2f6ef);color:#0ca998}
.mnav[data-tab="more"] .mnav-icon{background:linear-gradient(145deg,#fff4df,#ffe9c7);color:#e58b17}
.mnav[data-tab="home"] .mnav-icon svg,.mnav[data-tab="orders"] .mnav-icon svg,.mnav[data-tab="inventory"] .mnav-icon svg,.mnav[data-tab="more"] .mnav-icon svg{stroke:currentColor}
.mnav b{font-size:9px!important;font-weight:750;line-height:1.1;white-space:nowrap}
.mnav.active{background:transparent!important;color:#6546f6!important;box-shadow:none!important}
.mnav.active .mnav-icon{transform:translateY(-1px);box-shadow:0 5px 13px rgba(101,70,246,.09),inset 0 0 0 1px rgba(101,70,246,.06)}
.mnav.ai-nav{overflow:visible;gap:4px}
.mnav.ai-nav .ai-btn{width:68px!important;height:68px!important;margin-top:-31px!important;border:4px solid #fff!important;outline:2px solid #e4dcff!important;border-radius:50%!important;transform:none!important;display:grid;place-items:center;background:radial-gradient(circle at 32% 24%,#896aff,#6841f4 62%,#5733df)!important;color:#fff!important;font-size:30px!important;box-shadow:0 11px 28px rgba(101,70,246,.32),inset 0 1px 0 rgba(255,255,255,.4)!important}
.mnav.ai-nav b{margin-top:0;color:#6546f6!important;font-size:9px!important}
.mnav[data-tab="more"] .mnav-icon svg{stroke-width:2.2!important}
@media(max-width:760px){
 .marketplace-connect{padding:15px;margin-top:20px;border-radius:20px}
 .marketplace-connect .head{align-items:flex-start;margin-bottom:13px}
 .marketplace-connect .head h2{font-size:16px!important}
 .market-subtitle{font-size:10px!important;max-width:260px}
 .market-manage{padding:8px 9px;font-size:8px!important}
 .marketplace-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}
 .market-card{display:flex;min-height:0;padding:11px;gap:8px;border-radius:15px}
 .market-card-top{align-items:center}
 .market-logo{width:42px;height:42px;flex-basis:42px}
 .market-logo img{width:28px;height:28px}
 .market-status{font-size:6.5px}
 .market-info b{font-size:10px}
 .market-info small{font-size:7.5px}
 .connect-btn{min-height:34px;padding:8px 6px;font-size:8px;border-radius:9px}
 .mobile-nav{height:96px!important;padding-top:9px!important;padding-bottom:max(10px,env(safe-area-inset-bottom))!important}
 .mnav-icon{width:48px!important;height:44px!important;border-radius:15px!important}
 .mnav-icon svg{width:24px!important;height:24px!important}
 .mnav.ai-nav .ai-btn{width:66px!important;height:66px!important;margin-top:-30px!important}
 .mnav b{font-size:8.5px!important}
 .content{padding-bottom:120px}
}
@media(max-width:390px){
 .marketplace-connect{padding:12px}
 .market-card{padding:9px}
 .market-status{font-size:6px}
 .market-logo{width:38px;height:38px;flex-basis:38px}
 .market-logo img{width:25px;height:25px}
 .market-manage{font-size:7.5px!important;padding:7px}
 .mnav-icon{width:43px!important;height:41px!important}
 .mnav.ai-nav .ai-btn{width:61px!important;height:61px!important}
}
@media(min-width:761px){.marketplace-grid{grid-template-columns:repeat(4,minmax(0,1fr))}.market-card{display:grid;grid-template-columns:1fr;}}
'''
s=s.replace('</style>', css+'\n</style>', 1)
p.write_text(s)
print('updated',len(s),'bytes')
