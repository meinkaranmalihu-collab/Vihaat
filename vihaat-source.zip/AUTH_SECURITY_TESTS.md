# Vihaat authentication security update

## Included code changes
- Google ID tokens are verified by `google-auth-library` on the backend.
- Password hashes use Node.js `scrypt` and timing-safe comparison.
- Signed bearer tokens are bound to a server-side session record and expire after 7 days.
- Logout revokes the server-side session and clears browser token/user data.
- Login, signup, and Google login have per-IP in-memory rate limits.
- Basic security response headers are set; the app no longer enables unrestricted CORS.
- JSON request body limit reduced to 256 KB.

## Important limits
- Rate-limit counters are in-memory and reset when the service restarts; they are not a substitute for a distributed limiter/WAF for a multi-instance production service.
- The app still stores bearer tokens in localStorage. An HttpOnly cookie migration and CSRF protection should be considered before handling sensitive production data.
- The app's current JSONB whole-state persistence can have concurrent-write races; this patch does not solve that database architecture issue.
- Existing login tokens issued before this update do not contain server-side session IDs and will be rejected after deployment. Users will need to sign in again.
- No live Railway test has been performed by this patch.

## Deploy and test on Railway
1. Back up the current GitHub repository. Extract this ZIP and commit the extracted files at the repository root (do not upload the ZIP alone).
2. Ensure Railway has `DATABASE_URL`, `SESSION_SECRET` (random, at least 32 characters), and `GOOGLE_CLIENT_ID`. Keep secrets private.
3. Wait for Railway deployment to finish successfully.
4. Open `https://vihaat-production.up.railway.app/api/health`; expect HTTP 200 and `{"ok":true,...}`.
5. Test wrong password: should return HTTP 401 and not navigate to dashboard.
6. Test valid password and Google sign-in: should navigate to dashboard.
7. Open `https://vihaat-production.up.railway.app/api/auth/me` in a private tab without an Authorization header; expect HTTP 401.
8. In an authenticated browser, sign out, then try an authenticated API request using the old token. Expect HTTP 401 because the server-side session was revoked.
9. Try more than 10 failed email-login requests from the same IP within 15 minutes; subsequent requests should return HTTP 429.
10. Refresh the dashboard before sign-out (should stay signed in); after sign-out, use Back/refresh and verify the dashboard redirects and protected API requests fail.

Record the actual HTTP results before marking any test as passed.
