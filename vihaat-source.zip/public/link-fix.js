/* Vihaat navigation/auth CTA link layer.
   Keeps the existing landing-page design untouched while making all key CTA text actionable. */
(function(){
  function auth(mode){
    if(window.vihaatAuth && typeof window.vihaatAuth.open==='function'){
      window.vihaatAuth.open(mode);
      return true;
    }
    return false;
  }
  function textOf(el){return ((el.innerText||el.textContent||'').replace(/\s+/g,' ').trim()).toLowerCase()}
  document.addEventListener('click', function(e){
    const el=e.target && e.target.closest ? e.target.closest('a,button,[role="button"]') : null;
    if(!el || el.closest('#vihaat-auth-root')) return;
    if(el.id==='vh-menu-login' || el.id==='vh-menu-signup' || el.id==='vh-drawer-close') return;
    const t=textOf(el);
    if(t==='start for free' || t==='start free' || t.includes('start for free') || t.includes('start free')){
      e.preventDefault(); e.stopImmediatePropagation(); auth('signup'); return;
    }
    if(t==='sign in' || t==='login' || t==='log in'){
      e.preventDefault(); e.stopImmediatePropagation(); auth('login'); return;
    }
  }, true);

  function tagCTAs(){
    document.querySelectorAll('button,a,[role="button"]').forEach(el=>{
      if(el.closest('#vihaat-auth-root')) return;
      const t=textOf(el);
      if(t==='start for free' || t==='start free' || t.includes('start for free') || t.includes('start free')){
        el.setAttribute('data-auth-link','signup');
        if(el.tagName==='A') el.setAttribute('href','#signup');
      } else if(t==='sign in' || t==='login' || t==='log in'){
        el.setAttribute('data-auth-link','login');
        if(el.tagName==='A') el.setAttribute('href','#signin');
      }
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',tagCTAs,{once:true}); else tagCTAs();
  new MutationObserver(tagCTAs).observe(document.documentElement,{childList:true,subtree:true});
})();
