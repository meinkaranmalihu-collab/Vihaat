# Vihaat Commerce OS

Source package for the Vihaat landing page, seller dashboard, Express API, and visual assets.

## Run locally
- Node.js 20 or newer
- `npm install`
- `npm start`
- Open `http://localhost:3000`

## Production (GitHub + Railway)
See [`RAILWAY_SETUP.md`](./RAILWAY_SETUP.md). The project expects `package.json`, `Dockerfile`, `server/`, and `public/` at the repository root. Configure a Railway PostgreSQL database (`DATABASE_URL`) and a persistent `SESSION_SECRET` of at least 32 characters.

## Reliability changes in this package
- Signup normalizes email addresses and validates user input.
- Duplicate registration tells the user to sign in instead.
- Login normalizes email addresses and returns clearer errors for missing/incorrect credentials.
- Password verification safely rejects malformed stored hashes instead of throwing.
- Production startup reports a missing `SESSION_SECRET` immediately.
- Dashboard no longer displays fabricated KPI figures while API data is unavailable; unauthenticated sessions return to the landing page.

## Feature status (important)
The UI includes marketplace and AI feature concepts, but UI presence does not mean a production integration exists. Marketplace connect and remote inventory sync return an explicit not-configured response. Real marketplace OAuth/order sync/shipping labels and AI image/video providers require separate credentials and integration work. Gemini text generation requires `GEMINI_API_KEY`. Use `GET /api/health` to check service health.
