# Vihaat Commerce OS

Complete Vihaat source package with the existing landing page, dashboard, server, marketplace assets, social assets, and local visual assets.

## Dashboard visual and mobile fixes
- Mobile dashboard containers explicitly fill the viewport instead of appearing as a narrow centered strip.
- Tool cards use distinct, relevant local image assets rather than repeated/cropped thumbnails.
- Tool and product images use `object-fit: contain` so the full picture remains visible.
- Corrected the product thumbnail/label mismatch for the hoodie row.

## Run
Install dependencies with `npm install`, then start the server with `npm start`.


Dashboard refinement (2026-10-10): removed repeated tool cards and Settings from the dashboard tool catalog; Workspace now focuses on OMS order fulfilment shortcuts; Marketplace connections are accessed through the fifth mobile footer tab; Account remains accessible from the header. Mobile tool groups have refined card spacing and icons.


## Production readiness notes
- Set `SESSION_SECRET` to a random secret (32+ characters) in production.
- Configure Railway PostgreSQL and set `DATABASE_URL`; the server stores the application state in a PostgreSQL JSONB row when configured. Without it, local JSON storage is used and can be ephemeral on hosted platforms.
- Marketplace connect endpoints intentionally return a clear `503` until the marketplace adapter and credentials are configured.
- Label generation and dispatch do not fake a successful shipment. A connected marketplace integration must return a confirmed label before dispatch is allowed.
- Set `GEMINI_API_KEY` to enable the existing Gemini text endpoint. Image/video generation requires a separate provider adapter and is not claimed as active by this package.
