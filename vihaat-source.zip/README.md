# Vihaat Commerce OS

Complete Vihaat source package with the existing landing page, dashboard, server, marketplace assets, social assets, and local visual assets.

## Dashboard visual and mobile fixes
- Mobile dashboard containers explicitly fill the viewport instead of appearing as a narrow centered strip.
- Tool cards use distinct, relevant local image assets rather than repeated/cropped thumbnails.
- Tool and product images use `object-fit: contain` so the full picture remains visible.
- Corrected the product thumbnail/label mismatch for the hoodie row.

## Run
Install dependencies with `npm install`, then start the server with `npm start`.
