# Vihaat

Complete Vihaat Commerce OS source.

## CTA / authentication links
Key landing-page actions are wired to the existing authentication modal:
- Start for free / Start free -> Sign up
- Sign in / Login -> Sign in

The landing-page visual design is preserved; this change adds reliable CTA linking without changing the hero/header layout.


Dashboard visual update: tool cards and top-product rows now use local image thumbnails under `public/assets/tools/` and `public/assets/products/`. Marketplace and social logo assets remain in `public/assets/marketplaces/` and `public/assets/social/`.
