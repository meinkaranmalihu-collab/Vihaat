# VIHAAT

VIHAAT global ecommerce management platform prototype.

## Deploy on Railway
This repository is a static frontend served by Nginx. Railway can deploy it directly using the included `Dockerfile`.

1. Push these files to the `Vihaat` GitHub repository.
2. Railway → New Project → Deploy from GitHub Repo → `Vihaat`.
3. Railway detects the Dockerfile and builds the container.
4. No start command is required.
5. Port 80 is exposed by the Dockerfile; Railway supplies the public service port.

## Routes
- `/` — landing page
- `/dashboard.html` — authenticated prototype dashboard
- `/health` — deployment health check

## Prototype note
Authentication currently uses browser `localStorage` only. Production authentication, database, marketplace OAuth/API connections, payments, AI APIs, and background workers should be connected in the backend phase.
