# Vihaat deployment and feature-claim audit

## Deployment fix
The supplied archive placed the app inside `vihaat-audit/`, meaning the package manifest was not at the project root if the repository/build context used the archive root. This deliverable places `package.json`, `server/`, and `public/` at the root and includes a Dockerfile that installs dependencies from `package.json`.

## Landing page vs dashboard review
The landing page is `public/index.html`; the application dashboard is `public/dashboard.html`.
The current dashboard source includes UI cards for multiple tools. UI presence alone does not mean a tool is fully functional.
The server README documents that marketplace adapters/credentials are not configured, shipping-label generation must not fake success, and image/video generation needs a provider adapter. Those claims should be presented as unavailable/coming soon on the landing page until implemented and tested.

## Known integration limitations to resolve before advertising as live
- Marketplace OAuth/synchronization requires each marketplace adapter and credentials.
- Shipping labels must come from a connected marketplace/provider.
- Gemini text generation requires `GEMINI_API_KEY`.
- Image and video generation require provider adapters and credentials.
- PostgreSQL requires `DATABASE_URL`; local JSON fallback can be ephemeral on hosted platforms.

## Deployment
Configure `SESSION_SECRET` (32+ random characters) and `DATABASE_URL` in Railway. Deploy using the included Dockerfile or set the Railway root directory to this project root. Test `/api/health`, signup/login, product CRUD, and the dashboard after deploy.
