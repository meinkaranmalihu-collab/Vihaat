from pathlib import Path
p=Path('/tmp/vsrc/public/index.html')
s=p.read_text()
marker='</body>'
block=r'''
<style id="vihaat-side-menu-style">
#vh-menu-button{position:relative;width:42px;height:42px;flex:0 0 42px;border:1px solid rgba(0,0,0,.10);border-radius:14px;background:rgba(255,255,255,.86);backdrop-filter:blur(14px);display:grid;place-items:center;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.08);z-index:9998}
#vh-menu-button span,#vh-menu-button span:before,#vh-menu-button span:after{content:"";display:block;width:18px;height:2px;border-radius:4px;background:#111;transition:.22s}
#vh-menu-button span:before{transform:translateY(-6px)}#vh-menu-button span:after{transform:translateY(4px)}
body.vh-dark #vh-menu-button{background:rgba(20,24,40,.9);border-color:rgba(255,255,255,.12)}body.vh-dark #vh-menu-button span,body.vh-dark #vh-menu-button span:before,body.vh-dark #vh-menu-button span:after{background:#fff}
#vh-drawer-backdrop{position:fixed;inset:0;background:rgba(4,7,13,.46);backdrop-filter:blur(5px);z-index:9996;display:none}
#vh-drawer{position:fixed;z-index:9997;top:0;left:0;height:100dvh;width:min(360px,88vw);background:#fff;color:#0b0c10;box-shadow:24px 0 80px rgba(0,0,0,.22);transform:translateX(-102%);transition:transform .3s cubic-bezier(.22,1,.36,1);display:flex;flex-direction:column;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
#vh-drawer.open{transform:translateX(0)}#vh-drawer-backdrop.open{display:block}
.vh-drawer-head{padding:calc(18px + env(safe-area-inset-top)) 20px 18px;border-bottom:1px solid #ececf0;display:flex;align-items:center;justify-content:space-between}
.vh-drawer-brand{display:flex;align-items:center;gap:10px;font-weight:800;letter-spacing:-.03em;font-size:18px}.vh-drawer-brand img{width:42px;height:42px;border-radius:50%;object-fit:cover}.vh-drawer-close{width:38px;height:38px;border:0;border-radius:12px;background:#f2f3f5;font-size:24px;cursor:pointer}
.vh-drawer-auth{padding:16px 20px;border-bottom:1px solid #ececf0}.vh-drawer-auth-row{display:grid;grid-template-columns:1fr 1fr;gap:9px}.vh-drawer-auth button{height:44px;border-radius:12px;font-weight:750;cursor:pointer;font-size:14px}.vh-login{background:#fff;border:1px solid #dcdde2;color:#111}.vh-signup{background:#0b0b0d;border:1px solid #0b0b0d;color:#fff}
.vh-drawer-section{padding:18px 20px 8px;font-size:10px;font-weight:800;letter-spacing:.18em;color:#8a8d96}.vh-drawer-nav{padding:4px 12px 20px;overflow:auto}.vh-drawer-link{width:100%;display:flex;align-items:center;gap:12px;padding:12px 10px;border:0;background:transparent;border-radius:12px;text-align:left;font-size:14px;font-weight:650;color:#202228;cursor:pointer}.vh-drawer-link:hover{background:#f3f4f6}.vh-drawer-icon{width:30px;height:30px;border-radius:9px;background:#f0f1f4;display:grid;place-items:center;font-size:14px;flex:0 0 30px}.vh-drawer-foot{margin-top:auto;padding:14px 20px calc(18px + env(safe-area-inset-bottom));border-top:1px solid #ececf0;color:#8a8d96;font-size:11px}
body.vh-dark #vh-drawer{background:#0d1120;color:#fff}body.vh-dark .vh-drawer-head,body.vh-dark .vh-drawer-auth,body.vh-dark .vh-drawer-foot{border-color:rgba(255,255,255,.1)}body.vh-dark .vh-drawer-close{background:#1b2032;color:#fff}body.vh-dark .vh-login{background:transparent;border-color:rgba(255,255,255,.15);color:#fff}body.vh-dark .vh-signup{background:#fff;color:#0b0b0d;border-color:#fff}body.vh-dark .vh-drawer-link{color:#f5f6f8}body.vh-dark .vh-drawer-link:hover{background:#171c2d}body.vh-dark .vh-drawer-icon{background:#1a2030}
@media (min-width:768px){#vh-drawer{width:390px}}
</style>
<div id="vh-drawer-backdrop"></div>
<aside id="vh-drawer" aria-label="Vihaat navigation">
  <div class="vh-drawer-head"><div class="vh-drawer-brand"><img src="/assets/brand/vihaat-logo.png" alt="Vihaat"><span>VIHAAT</span></div><button class="vh-drawer-close" id="vh-drawer-close" aria-label="Close menu">×</button></div>
  <div class="vh-drawer-auth"><div class="vh-drawer-auth-row"><button class="vh-login" id="vh-menu-login">Sign in</button><button class="vh-signup" id="vh-menu-signup">Start for free</button></div></div>
  <div class="vh-drawer-section">SHORTCUTS</div>
  <nav class="vh-drawer-nav">
    <button class="vh-drawer-link" data-vh-target="home"><span class="vh-drawer-icon">⌂</span>Home</button>
    <button class="vh-drawer-link" data-vh-target="Global OMS"><span class="vh-drawer-icon">◎</span>Global OMS</button>
    <button class="vh-drawer-link" data-vh-target="Master Stock"><span class="vh-drawer-icon">▦</span>Master Stock</button>
    <button class="vh-drawer-link" data-vh-target="Vihaat AI"><span class="vh-drawer-icon">✦</span>Vihaat AI</button>
    <button class="vh-drawer-link" data-vh-target="AI Content"><span class="vh-drawer-icon">◈</span>AI Content Studio</button>
    <button class="vh-drawer-link" data-vh-target="Website Builder"><span class="vh-drawer-icon">▱</span>AI Website Builder</button>
    <button class="vh-drawer-link" data-vh-target="Dropshipping"><span class="vh-drawer-icon">⇄</span>Dropshipping</button>
    <button class="vh-drawer-link" data-vh-target="Pricing"><span class="vh-drawer-icon">₹</span>Pricing</button>
    <button class="vh-drawer-link" data-vh-target="Contact"><span class="vh-drawer-icon">✉</span>Contact</button>
  </nav>
  <div class="vh-drawer-foot">Commerce OS • One product. All marketplaces.</div>
</aside>
<script>
(()=>{
  const drawer=document.getElementById('vh-drawer'),back=document.getElementById('vh-drawer-backdrop');
  const open=()=>{drawer.classList.add('open');back.classList.add('open');document.body.style.overflow='hidden'};
  const close=()=>{drawer.classList.remove('open');back.classList.remove('open');document.body.style.overflow=''};
  document.getElementById('vh-drawer-close').onclick=close;back.onclick=close;
  const auth=(mode)=>{close(); if(window.vihaatAuth&&window.vihaatAuth.open) window.vihaatAuth.open(mode==='login'?'login':'signup');};
  document.getElementById('vh-menu-login').onclick=()=>auth('login');
  document.getElementById('vh-menu-signup').onclick=()=>auth('signup');
  function findTarget(q){
    if(q==='home'){window.scrollTo({top:0,behavior:'smooth'});return}
    const nodes=[...document.querySelectorAll('section,footer')];
    const n=nodes.find(el=>(el.innerText||'').toLowerCase().includes(q.toLowerCase()));
    if(n)n.scrollIntoView({behavior:'smooth',block:'start'});
    else window.scrollTo({top:0,behavior:'smooth'});
    close();
  }
  document.querySelectorAll('[data-vh-target]').forEach(b=>b.onclick=()=>findTarget(b.dataset.vhTarget));
  function installButton(){
    const header=document.querySelector('header');
    if(!header||document.getElementById('vh-menu-button'))return;
    const inner=header.firstElementChild;
    if(!inner)return;
    inner.style.position='relative';
    const btn=document.createElement('button');btn.id='vh-menu-button';btn.type='button';btn.setAttribute('aria-label','Open Vihaat menu');btn.innerHTML='<span></span>';
    btn.onclick=open;
    inner.insertBefore(btn,inner.firstElementChild);
    if(window.matchMedia('(max-width: 767px)').matches){
      const logoGroup=btn.nextElementSibling;
      if(logoGroup)logoGroup.style.marginLeft='2px';
    }
  }
  const obs=new MutationObserver(()=>installButton());obs.observe(document.body,{childList:true,subtree:true});
  installButton();setTimeout(installButton,300);setTimeout(installButton,1000);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
  const themeObs=new MutationObserver(()=>{document.body.classList.toggle('vh-dark',!!document.querySelector('header [aria-label="Toggle theme"]') && document.body.innerText.includes('☾'));});themeObs.observe(document.body,{subtree:true,childList:true});
})();
</script>
'''
s=s.replace(marker,block+marker)
p.write_text(s)
