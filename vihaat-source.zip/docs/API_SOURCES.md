# Vihaat API Integration Map

The bundled server is API-ready and keeps provider credentials server-side.

## Gemini
Use Google's Gemini API for Vihaat AI. Set GEMINI_API_KEY and GEMINI_MODEL in `.env`.

## Marketplace integrations
Each marketplace needs its own official seller/developer program, authorization flow and API credentials. Do not scrape seller portals.

- Amazon Selling Partner API (SP-API): seller/developer registration and OAuth authorization.
- Flipkart Seller APIs: Flipkart seller/developer access and seller authorization.
- Meesho Supplier APIs: access depends on the supplier/developer program available to the account.
- Myntra Partner/Seller integrations: access is through Myntra's partner/integration program.
- AJIO Seller/partner integrations: access is through Reliance/AJIO's partner program.
- Nykaa seller/partner integrations: access through Nykaa's seller/partner program.
- Snapdeal seller integrations: access through Snapdeal's seller/partner program.
- Shopify Admin API: create a Shopify custom/public app and use OAuth.
- eBay Sell APIs: create an eBay developer application and use OAuth.
- Walmart Marketplace APIs: apply for Walmart Marketplace developer access and OAuth.
- Etsy Open API: create an Etsy developer application and OAuth.

## Shipping / labels
For a multi-carrier label layer, integrate a shipping aggregator such as Shiprocket, NimbusPost, Easyship, or direct carrier APIs, subject to account/API access.

## Payments / credits
Use a payment gateway such as Razorpay, Cashfree or PayU for buying Vihaat credits. Never put secret keys in the browser.

## Production database
Move the bundled JSON persistence to PostgreSQL for production. Recommended: Neon, Supabase, Railway PostgreSQL, or a managed PostgreSQL instance.
