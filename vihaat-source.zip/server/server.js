import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DB = path.join(ROOT, 'data', 'db.json');
const USE_POSTGRES = Boolean(process.env.DATABASE_URL);
let pgPool = null;
if (USE_POSTGRES) { const { Pool } = await import('pg'); pgPool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'disable' ? false : (process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined), max: 5 }); }
const PORT = Number(process.env.PORT || 3000);
const app = express();
app.use(cors());
app.use(express.json({limit:'2mb'}));
app.use(express.static(path.join(ROOT,'public')));

const empty = {users:[],sessions:[],products:[],orders:[],inventory:[],returns:[],marketplaces:[],credits:[]};
async function readDb(){
  if (pgPool) {
    const result = await pgPool.query('SELECT data FROM vihaat_app_state WHERE id = 1');
    return result.rows[0]?.data || structuredClone(empty);
  }
  try { return JSON.parse(await fs.readFile(DB,'utf8')); } catch { return structuredClone(empty); }
}
async function writeDb(db){
  if (pgPool) {
    await pgPool.query('INSERT INTO vihaat_app_state (id, data, updated_at) VALUES (1, $1::jsonb, NOW()) ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()', [JSON.stringify(db)]);
    return;
  }
  await fs.mkdir(path.dirname(DB), { recursive: true });
  const temp = DB + '.tmp';
  await fs.writeFile(temp, JSON.stringify(db,null,2), { mode: 0o600 });
  await fs.rename(temp, DB);
}
const id=()=>crypto.randomUUID();
const now=()=>new Date().toISOString();
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){const hash=crypto.scryptSync(password,salt,64).toString('hex');return `${salt}:${hash}`}
function verifyPassword(password, stored) {
  try {
    if (typeof stored !== 'string') return false;
    const parts = stored.split(':');
    if (parts.length !== 2) return false;
    const [salt, hash] = parts;
    if (!salt || !/^[a-f0-9]{128}$/i.test(hash)) return false;
    const check = crypto.scryptSync(String(password), salt, 64);
    const expected = Buffer.from(hash, 'hex');
    return expected.length === check.length && crypto.timingSafeEqual(expected, check);
  } catch { return false; }
}
function sessionSecret(){const secret=process.env.SESSION_SECRET;if(process.env.NODE_ENV==='production'&&(!secret||secret.length<32))throw new Error('SESSION_SECRET must be set to a random value of at least 32 characters in production');return secret||'dev-only-secret-change-before-deploy-vihaat';}
function tokenFor(userId){const body=Buffer.from(JSON.stringify({uid:userId,exp:Date.now()+1000*60*60*24*7})).toString('base64url');const sig=crypto.createHmac('sha256',sessionSecret()).update(body).digest('base64url');return `${body}.${sig}`}
function userFromToken(t){try{const [body,sig]=t.split('.');if(!body||!sig)return null;const good=crypto.createHmac('sha256',sessionSecret()).update(body).digest('base64url');const a=Buffer.from(sig),b=Buffer.from(good);if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;const x=JSON.parse(Buffer.from(body,'base64url'));return x.exp>Date.now()?x.uid:null}catch{return null}}
async function auth(req,res,next){const h=req.headers.authorization||'';const uid=userFromToken(h.startsWith('Bearer ')?h.slice(7):'');if(!uid)return res.status(401).json({error:'Authentication required'});const db=await readDb();const user=db.users.find(u=>u.id===uid);if(!user)return res.status(401).json({error:'Session invalid'});req.user=user;req.db=db;next()}
function seedUser(db,user){if(db.credits.some(x=>x.userId===user.id))return;db.credits.push({userId:user.id,balance:10,used:0,updatedAt:now()})}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'vihaat-api',time:now()}));
app.post('/api/auth/signup', async (req, res) => {
  const body = req.body || {};
  const name = String(body.name || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const password = typeof body.password === 'string' ? body.password : '';
  const allowedCountries = ['IN', 'US', 'GB', 'AE'];
  const country = allowedCountries.includes(body.country) ? body.country : 'IN';
  if (name.length < 1 || name.length > 120 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 6 || password.length > 256) {
    return res.status(400).json({ error: 'Enter your name, a valid email, and a password of at least 6 characters.' });
  }
  const db = await readDb();
  if (db.users.some(u => String(u.email || '').trim().toLowerCase() === email)) {
    return res.status(409).json({ error: 'An account with this email already exists. Please sign in instead.' });
  }
  const user = { id: id(), name, email, passwordHash: hashPassword(password), country, createdAt: now() };
  db.users.push(user);
  seedUser(db, user);
  await writeDb(db);
  return res.status(201).json({ user: { id: user.id, name: user.name, email: user.email, country }, token: tokenFor(user.id) });
});
app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });
  const db = await readDb();
  const user = db.users.find(u => String(u.email || '').trim().toLowerCase() === email);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Email or password is incorrect. If you already registered, use the password you created your account with.' });
  }
  return res.json({ user: { id: user.id, name: user.name, email: user.email, country: user.country }, token: tokenFor(user.id) });
});
app.get('/api/auth/me',auth,(req,res)=>res.json({user:{id:req.user.id,name:req.user.name,email:req.user.email,country:req.user.country}}));
app.post('/api/auth/logout',auth,(req,res)=>res.json({ok:true}));

app.get('/api/dashboard',auth,async(req,res)=>{const d=req.db;const uid=req.user.id;const products=d.products.filter(x=>x.userId===uid);const orders=d.orders.filter(x=>x.userId===uid);const inv=d.inventory.filter(x=>x.userId===uid);const returns=d.returns.filter(x=>x.userId===uid);res.json({kpis:{newOrders:orders.filter(x=>x.status==='NEW').length,readyToDownload:orders.filter(x=>x.status==='READY_TO_DOWNLOAD').length,readyToDispatch:orders.filter(x=>x.status==='READY_TO_DISPATCH').length,totalStock:inv.reduce((a,x)=>a+x.stock,0),returns:returns.filter(x=>x.status!=='CLOSED').length,revenue:orders.reduce((a,x)=>a+(x.amount||0),0)},products,orders:orders.slice(-20).reverse(),inventory:inv,returns})});

app.get('/api/products',auth,(req,res)=>res.json(req.db.products.filter(x=>x.userId===req.user.id)));
app.post('/api/products',auth,async(req,res)=>{const {name,sku,price=0,stock=0}=req.body||{};if(!String(name||'').trim()||!String(sku||'').trim())return res.status(400).json({error:'name and sku required'});if(!Number.isFinite(Number(price))||Number(price)<0||!Number.isInteger(Number(stock))||Number(stock)<0)return res.status(400).json({error:'price must be non-negative and stock must be a non-negative integer'});if(req.db.products.some(x=>x.userId===req.user.id&&String(x.sku).toLowerCase()===String(sku).trim().toLowerCase()))return res.status(409).json({error:'SKU already exists for this account'});const p={id:id(),userId:req.user.id,name:String(name).trim(),sku:String(sku).trim(),price:Number(price),stock:Number(stock),createdAt:now(),updatedAt:now()};req.db.products.push(p);req.db.inventory.push({id:id(),userId:req.user.id,productId:p.id,sku,stock:Number(stock),reserved:0,updatedAt:now()});await writeDb(req.db);res.status(201).json(p)});
app.patch('/api/products/:id',auth,async(req,res)=>{const p=req.db.products.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!p)return res.status(404).json({error:'Product not found'});const allowed=['name','sku','price','stock'];for(const key of allowed){if(req.body?.[key]!==undefined)p[key]=req.body[key]}if(p.price!==undefined&&(!Number.isFinite(Number(p.price))||Number(p.price)<0))return res.status(400).json({error:'price must be non-negative'});if(p.stock!==undefined&&(!Number.isInteger(Number(p.stock))||Number(p.stock)<0))return res.status(400).json({error:'stock must be a non-negative integer'});p.updatedAt=now();const inv=req.db.inventory.find(x=>x.userId===req.user.id&&x.productId===p.id);if(inv&&p.stock!==undefined){inv.stock=Number(p.stock);inv.updatedAt=now()}await writeDb(req.db);res.json(p)});

app.get('/api/orders',auth,(req,res)=>{let o=req.db.orders.filter(x=>x.userId===req.user.id);if(req.query.status)o=o.filter(x=>x.status===req.query.status);res.json(o)});
app.post('/api/orders/:id/accept',auth,async(req,res)=>{const o=req.db.orders.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!o)return res.status(404).json({error:'Order not found'});o.status='READY_TO_DOWNLOAD';o.updatedAt=now();await writeDb(req.db);res.json(o)});
app.post('/api/orders/:id/label',auth,async(req,res)=>{const o=req.db.orders.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!o)return res.status(404).json({error:'Order not found'});return res.status(503).json({error:'A real marketplace-provided label is not available because no marketplace integration is connected.',code:'MARKETPLACE_NOT_CONNECTED',orderId:o.id});});
app.post('/api/orders/:id/dispatch',auth,async(req,res)=>{const o=req.db.orders.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!o)return res.status(404).json({error:'Order not found'});if(!o.label||o.label.status!=='GENERATED'||!o.label.providerOrderId)return res.status(409).json({error:'Cannot mark this order shipped without a confirmed marketplace shipment/label.',code:'SHIPMENT_NOT_CONFIRMED'});o.status='SHIPPED';o.updatedAt=now();await writeDb(req.db);res.json(o)});

app.get('/api/inventory',auth,(req,res)=>res.json(req.db.inventory.filter(x=>x.userId===req.user.id)));
app.post('/api/inventory/sync',auth,async(req,res)=>{return res.status(503).json({error:'Inventory is stored locally. Connect a marketplace adapter before requesting a remote sync.',code:'MARKETPLACE_NOT_CONNECTED'});});

app.get('/api/returns',auth,(req,res)=>res.json(req.db.returns.filter(x=>x.userId===req.user.id)));
app.post('/api/returns/:id/close',auth,async(req,res)=>{const r=req.db.returns.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!r)return res.status(404).json({error:'Return not found'});r.status='CLOSED';r.updatedAt=now();await writeDb(req.db);res.json(r)});

app.get('/api/marketplaces',auth,(req,res)=>{const country=req.user.country||'IN';const catalogs={IN:['Amazon India','Flipkart','Meesho','Myntra','AJIO','Nykaa','Snapdeal'],US:['Amazon US','Walmart','eBay','Etsy','Shopify'],GB:['Amazon UK','eBay UK','Shopify'],AE:['Amazon UAE','Noon','Shopify']};res.json((catalogs[country]||catalogs.IN).map(name=>({name,country,status:'NOT_CONNECTED'})))});
app.post('/api/marketplaces/:name/connect',auth,async(req,res)=>{res.status(503).json({error:'This marketplace adapter is not configured yet.',code:'ADAPTER_NOT_CONFIGURED',marketplace:req.params.name,requiredCredentials:['marketplace developer app approval','client ID and secret','seller authorization']})});

app.get('/api/credits',auth,(req,res)=>{seedUser(req.db,req.user);res.json(req.db.credits.find(x=>x.userId===req.user.id))});
app.post('/api/credits/consume',auth,async(req,res)=>{const amount=Math.max(0,Number(req.body?.amount||1));seedUser(req.db,req.user);const c=req.db.credits.find(x=>x.userId===req.user.id);if(c.balance<amount)return res.status(402).json({error:'Insufficient credits',credits:c});c.balance-=amount;c.used+=amount;c.updatedAt=now();await writeDb(req.db);res.json(c)});

app.post('/api/ai/gemini',auth,async(req,res)=>{const key=process.env.GEMINI_API_KEY;if(!key)return res.status(503).json({error:'Gemini API key not configured'});const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';const prompt=String(req.body?.prompt||'');if(!prompt)return res.status(400).json({error:'prompt required'});const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})});const data=await r.json();if(!r.ok)return res.status(r.status).json({error:data?.error?.message||'Gemini request failed'});const text=data?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'';res.json({text,raw:data})});

app.get('/api/country-config',auth,(req,res)=>res.json({country:req.user.country,pricingCurrency:{IN:'INR',US:'USD',GB:'GBP',AE:'AED'}[req.user.country]||'INR'}));
app.get('/app',(req,res)=>res.sendFile(path.join(ROOT,'public','dashboard.html')));
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
async function start(){
  if (process.env.NODE_ENV === 'production' && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
    throw new Error('Missing SESSION_SECRET. In Railway, add a random secret of at least 32 characters to the service Variables, then redeploy.');
  }
  if (pgPool) {
    await pgPool.query(`CREATE TABLE IF NOT EXISTS vihaat_app_state (id INTEGER PRIMARY KEY CHECK (id = 1), data JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    await pgPool.query('INSERT INTO vihaat_app_state (id, data) VALUES (1, $1::jsonb) ON CONFLICT (id) DO NOTHING', [JSON.stringify(empty)]);
    console.log('Vihaat persistence: PostgreSQL');
  } else {
    await fs.mkdir(path.dirname(DB), {recursive:true});
    console.warn('WARNING: DATABASE_URL is not set. Using local JSON storage; data may be lost on ephemeral hosting. Configure Railway PostgreSQL for persistent production data.');
  }
  app.listen(PORT,()=>console.log(`Vihaat API running on port ${PORT}`));
}
start().catch(err=>{console.error('Failed to initialize Vihaat:',err);process.exit(1)});
