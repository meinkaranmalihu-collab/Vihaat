# Vihaat: clean GitHub + Railway setup

## 1. Push the project to GitHub
- Extract this ZIP.
- Ensure `package.json`, `Dockerfile`, `server/`, and `public/` are at the repository root (not inside an extra nested folder).
- Commit and push the project to the branch Railway deploys, normally `main`.

## 2. Configure Railway
- Create/select a Railway project and deploy the GitHub repository.
- If using the included Dockerfile, leave the service root directory at the repository root.
- Add a Railway PostgreSQL database and ensure the app service receives `DATABASE_URL` from that database.
- Add `SESSION_SECRET` as a random value of at least 32 characters. Example generation command on a local computer: `node -e "console.log(require('node:crypto').randomBytes(48).toString('hex'))"`. Do not share or commit this secret.
- Optional: add `GEMINI_API_KEY` to enable the text-based Gemini endpoint.
- Redeploy after setting variables.

## 3. Verify deployment
1. Open `https://YOUR-RAILWAY-DOMAIN/api/health`; expected JSON includes `"ok":true`.
2. Create an account with a new email and a password of at least six characters.
3. Sign out, then sign in using the same email and password.
4. Add a test product and verify it remains after a redeploy.
5. Confirm invalid credentials are rejected and a stale token returns to the landing page.

## Important current limitations
Marketplace connection and remote inventory sync endpoints deliberately report that integrations are not configured. Real marketplace OAuth, order import, shipping labels, AI image generation, and video generation are not made live by this deployment package. Gemini text generation requires a valid `GEMINI_API_KEY`. Do not market these integrations as operational until each is implemented and tested.
