# Vihaat Google Sign-In setup

This patch adds Google Identity Services to the existing signup/login modal and verifies ID tokens on the server with `google-auth-library`.

## Railway variables
- `GOOGLE_CLIENT_ID`: the Web application OAuth Client ID ending in `apps.googleusercontent.com`.
- Keep `SESSION_SECRET` private and at least 32 characters.
- Keep `DATABASE_URL` configured for PostgreSQL.

## Google Cloud OAuth client
- Authorized JavaScript origin: `https://vihaat-production.up.railway.app`
- Add `https://vihaat.com` and `https://www.vihaat.com` only after those domains point to Vihaat.
- This implementation uses the Google Identity Services credential callback and backend ID-token verification, so it does not require a redirect URI.
- While the OAuth consent screen is in Testing, add your Google account under Audience / Test users. For public launch, complete Google's publishing requirements and move to production.

## Deploy
Commit the extracted contents of this ZIP to the root of the GitHub repository (not the ZIP file alone), then let Railway build the app. Verify `GET /api/health`, then test signup/login and Google Sign-In in a private browser session.
